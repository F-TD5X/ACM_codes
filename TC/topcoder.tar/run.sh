#!/bin/sh
java -classpath "lib/*" com.topcoder.client.contestApplet.runner.generic www.topcoder.com 5001 >/dev/null 2>&1 &
